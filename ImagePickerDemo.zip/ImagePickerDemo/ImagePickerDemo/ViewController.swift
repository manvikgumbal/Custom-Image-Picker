//
//  ViewController.swift
//  ImagePickerDemo
//
//  Created by 123 on 09/09/16.
//  Copyright © 2016 123. All rights reserved.
//

import UIKit

class ViewController: UIViewController, CustomPickerViewDelegate {

    @IBOutlet weak var demoImageView: UIImageView!
    var imagePicker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        CustomImagePickerView.sharedInstace.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnAction(sender: UIButton) {
        let alert = UIAlertController(title: "Select Image", message: nil, preferredStyle: .ActionSheet)
        alert.addAction(UIAlertAction(title: "Gallery", style: .Default, handler: {action in
            CustomImagePickerView.sharedInstace.pickImageUsing(target: self, mode: .Gallery)
        }))
        alert.addAction(UIAlertAction(title: "Camera", style: .Default, handler: {action in
            CustomImagePickerView.sharedInstace.pickImageUsing(target: self, mode: .Camera)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
        
    }
    
    func didImagePickerFinishPicking(image: UIImage) {
        demoImageView.image = image
    }

}

